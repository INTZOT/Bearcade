import { world, system, EquipmentSlot, ItemStack, MolangVariableMap } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";

// ============ 常量 ============
const HB = "minecraft:health_boost";
const REGEN = "minecraft:regeneration";
const ABSORPTION = "minecraft:absorption";
const RESISTANCE = "minecraft:resistance";
const STRENGTH = "minecraft:strength";
const SLOWNESS = "minecraft:slowness";
const POISON = "minecraft:poison";
const FATAL_POISON = "minecraft:fatal_poison";
const INSTANT_HEALTH = "minecraft:instant_health";
const INVISIBILITY = "minecraft:invisibility";
const SPEED = "minecraft:speed";

const NEGATIVE_EFFECTS = [
  SLOWNESS,
  POISON,
  FATAL_POISON,
  "minecraft:weakness",
  "minecraft:blindness",
  "minecraft:nausea",
  "minecraft:hunger",
  "minecraft:wither",
  "minecraft:mining_fatigue",
  "minecraft:darkness",
  "minecraft:levitation"
];

const SCHOOLS = [
  { id: "jiemie", name: "输出丨击灭学派", weapon: "jimie:halberd", skill1: "jimie:charge", skill2: "jimie:heal" },
  { id: "fuzu", name: "控制丨缚阻学派", weapon: "jimie:wand_bind", skill1: "jimie:slow_field", skill2: "jimie:poison_field" },
  { id: "life", name: "治疗丨生命学派", weapon: "jimie:wand_life", skill1: "jimie:same_boat", skill2: "jimie:bless" },
  { id: "speed", name: "游走丨疾行学派", weapon: "jimie:longsword", skill1: "jimie:dash", skill2: "jimie:stealth" }
];

const TOMES = [
  { id: "buddha", name: "禅师丨布德宗圣典", item: "jimie:tome_buddha" },
  { id: "priest", name: "司铎丨卡鲁教廷圣典", item: "jimie:tome_priest" },
  { id: "knight", name: "骑士丨“南十字”法典", item: "jimie:tome_knight" },
  { id: "doctor", name: "医师丨塔莫琳秘典", item: "jimie:tome_doctor" },
  { id: "summoner", name: "召唤师丨芙希秘典", item: "jimie:tome_summoner" },
  { id: "blade", name: "魔剑士丨阿玛拉加秘典", item: "jimie:tome_blade" },
  { id: "herbalist", name: "药师丨茶雅秘典", item: "jimie:tome_herbalist" },
  { id: "prophet", name: "预言家丨普林西斯秘典", item: "jimie:tome_prophet" },
  { id: "formation", name: "阵法师丨佩莉秘典", item: "jimie:tome_formation" }
];

const RED_TAG = "jimie_red";
const BLUE_TAG = "jimie_blue";

// ============ 运行时状态 ============
const blessBoostUntil = new Map(); // playerId -> tick
const immuneUntil = new Map();      // playerId -> tick
const fallImmuneUntil = new Map();  // playerId -> tick
const totemState = new Map();       // playerId -> { had }
const indicators = new Map();       // entityId -> indicator 数据
const peiliIndicators = new Map();  // ownerId -> entityId
const prophets = new Map();         // indicatorId -> Map(enemyId -> markerId)
const wolves = new Map();           // wolfId -> { ownerId, expireTick }
const lastUse = new Map();          // playerId -> { tick, id } 防止 itemUse/itemUseOn 重复触发

// ============ 基础工具 ============
function teamOf(entity) {
  if (!entity) return "";
  if (entity.hasTag(RED_TAG)) return RED_TAG;
  if (entity.hasTag(BLUE_TAG)) return BLUE_TAG;
  return "";
}

function isEnemy(a, b) {
  const ta = teamOf(a), tb = teamOf(b);
  return ta !== "" && tb !== "" && ta !== tb;
}

function isFriendly(a, b) {
  const ta = teamOf(a), tb = teamOf(b);
  return ta !== "" && ta === tb;
}

function isEnemyByTeam(entity, team) {
  const t = teamOf(entity);
  return t !== "" && t !== team;
}

function parseVec(s) {
  const parts = String(s).split(",");
  if (parts.length < 3) return { x: 0, y: 0, z: 0 };
  return { x: Number(parts[0]), y: Number(parts[1]), z: Number(parts[2]) };
}

function vecKey(v) {
  return v.x + "," + v.y + "," + v.z;
}

function nearPoint(entity, p) {
  const pts = [entity.location, { x: entity.location.x, y: entity.location.y + 1.2, z: entity.location.z }];
  for (const q of pts) {
    const dx = q.x - p.x, dy = q.y - p.y, dz = q.z - p.z;
    if (dx * dx + dy * dy + dz * dz < 1.0) return true;
  }
  return false;
}

function playersInCylinder(center, radius, halfHeight, filter) {
  return world.getAllPlayers().filter((p) => {
    if (p.dimension.id !== center.dim) return false;
    const dx = p.location.x - center.x;
    const dy = p.location.y - center.y;
    const dz = p.location.z - center.z;
    if (dx * dx + dz * dz > radius * radius) return false;
    if (Math.abs(dy) > halfHeight) return false;
    return !filter || filter(p);
  });
}

function rayToBlock(player, maxDist) {
  const dim = player.dimension;
  const origin = player.getHeadLocation();
  const dir = player.getViewDirection();
  const step = 0.25;
  let lastAir = { x: origin.x, y: origin.y, z: origin.z };
  for (let d = step; d <= maxDist; d += step) {
    const p = { x: origin.x + dir.x * d, y: origin.y + dir.y * d, z: origin.z + dir.z * d };
    const b = dim.getBlock({ x: Math.floor(p.x), y: Math.floor(p.y), z: Math.floor(p.z) });
    if (b && b.isSolid) return { hit: p, lastAir: lastAir };
    lastAir = p;
  }
  return undefined;
}

function findSafeTeleport(dim, pos) {
  const h = dim.heightRange;
  for (let i = 0; i < 8; i++) {
    const y = pos.y + i;
    if (y < h.min || y + 1 > h.max) break;
    const f = dim.getBlock({ x: Math.floor(pos.x), y: Math.floor(y), z: Math.floor(pos.z) });
    const hd = dim.getBlock({ x: Math.floor(pos.x), y: Math.floor(y + 1), z: Math.floor(pos.z) });
    if ((!f || !f.isSolid) && (!hd || !hd.isSolid)) return { x: pos.x, y: y, z: pos.z };
  }
  return pos;
}

function blockedAt(dim, pos) {
  const h = dim.heightRange;
  if (pos.y < h.min || pos.y + 1 > h.max) return true;
  const b1 = dim.getBlock({ x: Math.floor(pos.x), y: Math.floor(pos.y), z: Math.floor(pos.z) });
  const b2 = dim.getBlock({ x: Math.floor(pos.x), y: Math.floor(pos.y + 1), z: Math.floor(pos.z) });
  return (b1 && b1.isSolid) || (b2 && b2.isSolid);
}

function spawnBurst(dim, loc, particle) {
  for (let i = 0; i < 8; i++) {
    dim.spawnParticle(particle, {
      x: loc.x + (Math.random() - 0.5) * 1.5,
      y: loc.y + Math.random() * 1.5,
      z: loc.z + (Math.random() - 0.5) * 1.5
    });
  }
}

function beamParticles(dim, center, color, height) {
  try {
    const mv = new MolangVariableMap();
    mv.setColorRGB("variable.color", color);
    for (let y = 0; y <= height; y += 2) {
      dim.spawnParticle("minecraft:colored_flame_particle", {
        x: center.x + (Math.random() - 0.5) * 0.5,
        y: center.y + y,
        z: center.z + (Math.random() - 0.5) * 0.5
      }, mv);
    }
  } catch (e) {}
}

function colorFor(skill) {
  switch (skill) {
    case "slow": return { red: 0.35, green: 0.7, blue: 1.0 };
    case "poison_field": return { red: 0.75, green: 0.2, blue: 0.9 };
    case "herbalist": return { red: 0.35, green: 0.9, blue: 0.35 };
    case "prophet": return { red: 1.0, green: 0.85, blue: 0.2 };
    default: return { red: 0.9, green: 0.9, blue: 0.9 };
  }
}

function removeNegatives(p) {
  for (const ef of NEGATIVE_EFFECTS) {
    try { p.removeEffect(ef); } catch (e) {}
  }
}

function hasItem(container, typeId) {
  for (let i = 0; i < container.size; i++) {
    const it = container.getItem(i);
    if (it && it.typeId === typeId) return true;
  }
  return false;
}

// ============ 队伍（占位方案） ============
function setTeam(p, tag) {
  p.removeTag(RED_TAG);
  p.removeTag(BLUE_TAG);
  p.addTag(tag);
  p.sendMessage("§a你已加入" + (tag === RED_TAG ? "红队" : "蓝队"));
}

function assignTeam(p) {
  let r = 0, b = 0;
  for (const q of world.getAllPlayers()) {
    if (q.hasTag(RED_TAG)) r++;
    else if (q.hasTag(BLUE_TAG)) b++;
  }
  p.addTag(r <= b ? RED_TAG : BLUE_TAG);
  p.sendMessage("§a自动分配：" + (teamOf(p) === RED_TAG ? "红队" : "蓝队") + "，可用 !team red/blue 切换");
}

// ============ 全局生命提升 ============
function applyGlobalBoosts(player) {
  try {
    player.addEffect(HB, 40, { amplifier: 4, showParticles: false });
    const hc = player.getComponent("minecraft:health");
    const max = hc && hc.effectiveMax !== undefined ? hc.effectiveMax : (hc ? hc.currentValue : 20);
    player.setHealth(max);
  } catch (e) {}
}

// ============ 选择与发放 ============
function startSelection(player) {
  const form = new ActionFormData();
  form.title("选择学派");
  form.body("请选择你的学派（武器与两个技能固定）");
  for (const s of SCHOOLS) form.button(s.name);
  form.show(player).then((res) => {
    if (res.canceled || res.selection === undefined) {
      system.runTimeout(() => {
        if (player.isValid && !player.getDynamicProperty("jimie_school")) startSelection(player);
      }, 20);
      return;
    }
    player.setDynamicProperty("jimie_school", SCHOOLS[res.selection].id);
    chooseTome(player, []);
  }).catch(() => {
    system.runTimeout(() => {
      if (player.isValid && !player.getDynamicProperty("jimie_school")) startSelection(player);
    }, 20);
  });
}

function chooseTome(player, chosen) {
  if (chosen.length >= 2) {
    player.setDynamicProperty("jimie_tome1", chosen[0]);
    player.setDynamicProperty("jimie_tome2", chosen[1]);
    ensureLoadout(player);
    player.sendMessage("§a已选择流派与两本圣典，物品已发放到背包");
    return;
  }
  const form = new ActionFormData();
  form.title("选择圣典/法典/秘典（" + (chosen.length + 1) + "/2）");
  form.body("请选择第 " + (chosen.length + 1) + " 本");
  const remaining = TOMES.filter((t) => !chosen.includes(t.id));
  for (const t of remaining) form.button(t.name);
  form.show(player).then((res) => {
    if (res.canceled || res.selection === undefined) {
      system.runTimeout(() => {
        if (player.isValid && !player.getDynamicProperty("jimie_tome1")) chooseTome(player, chosen);
      }, 20);
      return;
    }
    chosen.push(remaining[res.selection].id);
    chooseTome(player, chosen);
  }).catch(() => {
    system.runTimeout(() => {
      if (player.isValid && !player.getDynamicProperty("jimie_tome1")) chooseTome(player, chosen);
    }, 20);
  });
}

function ensureLoadout(player) {
  const school = SCHOOLS.find((s) => s.id === player.getDynamicProperty("jimie_school"));
  if (!school) return;
  const t1 = TOMES.find((t) => t.id === player.getDynamicProperty("jimie_tome1"));
  const t2 = TOMES.find((t) => t.id === player.getDynamicProperty("jimie_tome2"));
  if (!t1 || !t2) return;
  const ids = [school.weapon, school.skill1, school.skill2, t1.item, t2.item];
  const inv = player.getComponent("minecraft:inventory").container;
  for (const id of ids) {
    if (hasItem(inv, id)) continue;
    const rest = inv.addItem(new ItemStack(id));
    if (rest) {
      try { player.dimension.spawnItem(rest, player.location); } catch (e) {}
    }
  }
}

// ============ 射线武器 ============
function wandShot(player, damage) {
  const dim = player.dimension;
  const origin = player.getHeadLocation();
  const dir = player.getViewDirection();
  const enemies = world.getAllPlayers().filter((e) => isEnemy(player, e) && e.dimension.id === dim.id);
  const step = 0.25;
  let lastP = origin;
  let hit = null;
  for (let d = step; d <= 35; d += step) {
    const p = { x: origin.x + dir.x * d, y: origin.y + dir.y * d, z: origin.z + dir.z * d };
    lastP = p;
    for (const e of enemies) {
      if (nearPoint(e, p)) {
        hit = { type: "player", entity: e, point: p };
        break;
      }
    }
    if (hit) break;
    const b = dim.getBlock({ x: Math.floor(p.x), y: Math.floor(p.y), z: Math.floor(p.z) });
    if (b && b.isSolid) {
      hit = { type: "block", point: p };
      break;
    }
  }
  for (let k = 2; k <= 34; k += 2) {
    dim.spawnParticle("minecraft:spell", { x: origin.x + dir.x * k, y: origin.y + dir.y * k, z: origin.z + dir.z * k });
  }
  const end = hit ? hit.point : lastP;
  if (hit && hit.type === "player") {
    try { hit.entity.damage(damage, { cause: "magic", damagingEntity: player }); } catch (e) {}
    spawnBurst(dim, end, "minecraft:critical_hit");
  } else {
    spawnBurst(dim, end, "minecraft:endrod");
  }
  dim.playSound("mob.blaze.shoot", end);
}

// ============ 击灭学派 ============
function skillCharge(player) {
  const dim = player.dimension;
  const enemies = world.getAllPlayers().filter((e) => isEnemy(player, e) && e.dimension.id === dim.id);
  const view = player.getViewDirection();
  const vh = Math.hypot(view.x, view.z);
  const hitList = [];
  if (vh > 0.001) {
    const vx = view.x / vh, vz = view.z / vh;
    for (const e of enemies) {
      const dx = e.location.x - player.location.x;
      const dz = e.location.z - player.location.z;
      const dy = e.location.y - player.location.y;
      const distH = Math.hypot(dx, dz);
      if (distH > 13 || Math.abs(dy) > 7.5) continue;
      const dot = (dx * vx + dz * vz) / distH;
      const ang = Math.acos(Math.max(-1, Math.min(1, dot))) * 180 / Math.PI;
      if (ang <= 20) hitList.push(e);
    }
  }
  for (const e of hitList) {
    try { e.damage(6, { cause: "magic", damagingEntity: player }); } catch (err) {}
  }
  const dest = { x: player.location.x + view.x * 13, y: player.location.y + 3.5, z: player.location.z + view.z * 13 };
  const safe = findSafeTeleport(dim, dest);
  for (const e of [...hitList, player]) {
    try { e.teleport(safe); } catch (err) {}
  }
  fallImmuneUntil.set(player.id, system.currentTick + 60);
  dim.playSound("mob.enderman.teleport", safe);
  for (const e of hitList) spawnBurst(dim, e.location, "minecraft:critical_hit");
  player.sendMessage("§c击灭丨突进：命中 " + hitList.length + " 名敌人");
}

function skillHeal(player) {
  player.addEffect(REGEN, 40, { amplifier: 2 });
  player.addEffect(ABSORPTION, 200, { amplifier: 2 });
  player.dimension.playSound("random.levelup", player.location);
  spawnBurst(player.dimension, player.location, "minecraft:villager_happy");
  player.sendMessage("§a击灭丨战愈：恢复III 2s + 吸收III 10s");
}

// ============ 缚阻学派 ============
function placeField(player, skill, radius, effect, amplifier, durationTicks, name) {
  const t = rayToBlock(player, 35);
  if (!t) {
    player.sendMessage("§c35格内没有可放置指示物的方块");
    return;
  }
  spawnIndicator(skill, {
    x: t.lastAir.x,
    y: t.lastAir.y,
    z: t.lastAir.z,
    dim: player.dimension.id
  }, radius, effect, amplifier, durationTicks, player);
  player.sendMessage("§a" + name + "：指示物已放置");
}

function skillSlowField(player) {
  placeField(player, "slow", 10, SLOWNESS, 1, 200, "缚阻丨迟滞");
}

function skillPoisonField(player) {
  placeField(player, "poison_field", 10, FATAL_POISON, 1, 300, "缚阻丨瘴阵");
}

// ============ 生命学派 ============
function skillSameBoat(player) {
  const t = rayToBlock(player, 35);
  if (!t) {
    player.sendMessage("§c35格内没有可用方块目标");
    return;
  }
  const center = { x: t.lastAir.x, y: t.lastAir.y, z: t.lastAir.z, dim: player.dimension.id };
  const friends = playersInCylinder(center, 7, 7.5, (q) => isFriendly(player, q) && q.id !== player.id);
  for (const f of friends) {
    try { f.addEffect(INSTANT_HEALTH, 1, { amplifier: 1, showParticles: true }); } catch (e) {}
  }
  try { player.damage(6, { cause: "magic", damagingEntity: player }); } catch (e) {}
  player.dimension.playSound("random.levelup", center);
  beamParticles(player.dimension, center, { red: 0.4, green: 1.0, blue: 0.5 }, 6);
  player.sendMessage("§a生命丨同舟：队友治疗II，自身受到3颗心伤害");
}

function skillBless(player) {
  const t = rayToBlock(player, 35);
  if (!t) {
    player.sendMessage("§c35格内没有可用方块目标");
    return;
  }
  const center = { x: t.lastAir.x, y: t.lastAir.y, z: t.lastAir.z, dim: player.dimension.id };
  const friends = playersInCylinder(center, 7, 7.5, (q) => isFriendly(player, q));
  const now = system.currentTick;
  for (const f of friends) {
    try {
      f.addEffect(INSTANT_HEALTH, 1, { amplifier: 2, showParticles: true });
      f.addEffect(HB, 300, { amplifier: 7, showParticles: true });
      blessBoostUntil.set(f.id, now + 300);
      immuneUntil.set(f.id, now + 100);
      removeNegatives(f);
    } catch (e) {}
  }
  player.dimension.playSound("random.levelup", center);
  beamParticles(player.dimension, center, { red: 1.0, green: 0.9, blue: 0.4 }, 7);
  player.sendMessage("§a生命丨祝福：友方治疗III + 生命提升VIII 15s + 免疫负面5s");
}

// ============ 疾行学派 ============
function skillDash(player) {
  const dim = player.dimension;
  const view = player.getViewDirection();
  const vh = Math.hypot(view.x, view.z);
  if (vh < 0.001) return;
  const dir = { x: view.x / vh, z: view.z / vh };
  const path = [];
  let cur = { x: player.location.x, y: player.location.y, z: player.location.z };
  for (let i = 0; i < 20; i++) {
    const next = { x: cur.x + dir.x * 0.5, y: cur.y, z: cur.z + dir.z * 0.5 };
    if (blockedAt(dim, next)) break;
    path.push(next);
    cur = next;
  }
  if (path.length === 0) {
    player.sendMessage("§c前方被阻挡");
    return;
  }
  let idx = 0;
  const runId = system.runInterval(() => {
    if (!player.isValid) {
      system.clearRun(runId);
      return;
    }
    for (let k = 0; k < 2 && idx < path.length; k++, idx++) {
      try { player.teleport(path[idx]); } catch (err) {
        system.clearRun(runId);
        return;
      }
    }
    if (idx >= path.length) system.clearRun(runId);
  }, 1);
  dim.playSound("mob.enderman.teleport", player.location);
  player.sendMessage("§a疾行丨掠影：向前高速位移10格");
}

function skillStealth(player) {
  player.addEffect(INVISIBILITY, 300, { amplifier: 0 });
  player.addEffect(SPEED, 300, { amplifier: 1 });
  player.sendMessage("§a疾行丨隐袭：隐身15s + 速度II 15s");
}

// ============ 圣典/法典/秘典 ============
function tomeBuddhaStatus(player) {
  const remain = Number(player.getDynamicProperty("jimie_totem_remain") || 0);
  const eq = player.getComponent("minecraft:equippable");
  const off = eq ? eq.getEquipment(EquipmentSlot.Offhand) : undefined;
  const has = !!off && off.typeId === "minecraft:totem_of_undying";
  if (has) player.sendMessage("§a不死图腾已就绪");
  else if (remain > 0) player.sendMessage("§6图腾冷却中：" + Math.ceil(remain) + "s");
  else player.sendMessage("§c图腾缺失，冷却结束后将自动补充");
}

function tomePriest(player) {
  immuneUntil.set(player.id, system.currentTick + 160);
  removeNegatives(player);
  player.sendMessage("§a卡鲁教廷圣典：8s内免疫负面状态");
}

function tomeKnight(player) {
  player.addEffect(ABSORPTION, 200, { amplifier: 2 });
  player.addEffect(RESISTANCE, 200, { amplifier: 0 });
  player.sendMessage("§a南十字法典：吸收III + 抗性I 10s");
}

function tomeDoctor(player) {
  player.addEffect(REGEN, 200, { amplifier: 1 });
  player.sendMessage("§a塔莫琳秘典：恢复II 10s");
}

function tomeSummoner(player) {
  const team = teamOf(player);
  const variant = team === RED_TAG ? "jimie:fuxi_wolf_red" : "jimie:fuxi_wolf_blue";
  const now = system.currentTick;
  for (let i = 0; i < 2; i++) {
    const loc = { x: player.location.x + (i === 0 ? 0.7 : -0.7), y: player.location.y, z: player.location.z };
    try {
      const wolf = player.dimension.spawnEntity(variant, loc);
      const tameable = wolf.getComponent("minecraft:tameable");
      if (tameable && typeof tameable.tame === "function") {
        try { tameable.tame(player); } catch (e) {}
      }
      try { wolf.triggerEvent("jimie:on_tame"); } catch (e) {}
      wolf.setDynamicProperty("jimie_owner", player.id);
      wolf.setDynamicProperty("jimie_remain", 700);
      wolves.set(wolf.id, { ownerId: player.id, expireTick: now + 700 });
    } catch (e) {}
  }
  player.dimension.playSound("random.levelup", player.location);
  player.sendMessage("§a芙希秘典：召唤两只狗（35s）");
}

function tomeBlade(player) {
  try { player.damage(6, { cause: "magic", damagingEntity: player }); } catch (e) {}
  player.addEffect(POISON, 40, { amplifier: 1 });
  player.addEffect(STRENGTH, 140, { amplifier: 0 });
  player.sendMessage("§a阿玛拉加秘典：自伤3颗心 + 中毒II 2s + 力量I 7s");
}

function tomeHerbalist(player) {
  placeField(player, "herbalist", 5, POISON, 0, 160, "药师丨茶雅秘典");
}

function tomeProphet(player) {
  const t = rayToBlock(player, 35);
  if (!t) {
    player.sendMessage("§c35格内没有可放置指示物的方块");
    return;
  }
  spawnIndicator("prophet", {
    x: t.lastAir.x,
    y: t.lastAir.y,
    z: t.lastAir.z,
    dim: player.dimension.id
  }, 15, "", 0, 500, player);
  player.sendMessage("§a普林西斯秘典：标记指示物已放置（25s）");
}

function tomeFormation(player) {
  const oldId = peiliIndicators.get(player.id);
  if (oldId) {
    const old = world.getEntity(oldId);
    if (old && old.isValid) {
      try { old.kill(); } catch (e) {}
    }
    peiliIndicators.delete(player.id);
  }
  const dim = player.dimension;
  let below;
  try { below = dim.getBlockBelow(player.location); } catch (e) {}
  if (!below) {
    player.sendMessage("§c下方没有可放置的地面");
    return;
  }
  const loc = { x: Math.floor(below.location.x) + 0.5, y: below.location.y + 1.0, z: Math.floor(below.location.z) + 0.5 };
  const ent = dim.spawnEntity("jimie:peili_indicator", loc);
  ent.setDynamicProperty("jimie_owner", player.id);
  ent.setDynamicProperty("jimie_hits", 0);
  peiliIndicators.set(player.id, ent.id);
  dim.playSound("random.orb", loc);
  player.sendMessage("§a佩莉秘典：阵眼已放置");
}

// ============ 指示物 ============
function spawnIndicator(skill, center, radius, effect, amplifier, durationTicks, player) {
  const ent = player.dimension.spawnEntity("jimie:area_indicator", { x: center.x, y: center.y, z: center.z });
  ent.setDynamicProperty("jimie_skill", skill);
  ent.setDynamicProperty("jimie_team", teamOf(player));
  ent.setDynamicProperty("jimie_center", vecKey(center));
  ent.setDynamicProperty("jimie_radius", radius);
  ent.setDynamicProperty("jimie_effect", effect || "");
  ent.setDynamicProperty("jimie_amplifier", amplifier);
  ent.setDynamicProperty("jimie_remain", durationTicks);
  indicators.set(ent.id, {
    skill: skill,
    team: teamOf(player),
    center: { x: center.x, y: center.y, z: center.z, dim: player.dimension.id },
    radius: radius,
    effect: effect || "",
    amplifier: amplifier,
    expireTick: system.currentTick + durationTicks
  });
  ent.dimension.playSound("random.orb", ent.location);
}

function tickIndicators() {
  for (const [id, ind] of [...indicators]) {
    const ent = world.getEntity(id);
    if (!ent || !ent.isValid || system.currentTick >= ind.expireTick) {
      if (ent && ent.isValid) {
        try { ent.kill(); } catch (e) {}
      }
      if (ind.skill === "prophet") clearProphetMarks(id);
      indicators.delete(id);
      continue;
    }
    const dim = ent.dimension;
    const center = { x: ind.center.x, y: ind.center.y, z: ind.center.z };
    beamParticles(dim, center, colorFor(ind.skill), ind.skill === "prophet" ? 15 : 8);
    if (ind.effect) {
      const enemies = playersInCylinder({ ...center, dim: dim.id }, ind.radius, 7.5, (q) => isEnemyByTeam(q, ind.team));
      for (const e of enemies) {
        try { e.addEffect(ind.effect, 40, { amplifier: ind.amplifier, showParticles: false }); } catch (err) {}
      }
    }
    if (ind.skill === "prophet") manageProphetMarks(ind, ent, center);
    ent.setDynamicProperty("jimie_remain", Math.max(0, ind.expireTick - system.currentTick));
  }
}

// ============ 预言家标记 ============
function manageProphetMarks(ind, indicatorEnt, center) {
  let marks = prophets.get(ind.id) || new Map();
  const enemies = playersInCylinder({ ...center, dim: indicatorEnt.dimension.id }, ind.radius, 7.5, (q) => isEnemyByTeam(q, ind.team));
  const enemyIds = new Set(enemies.map((e) => e.id));
  for (const [eid, mid] of [...marks]) {
    const m = world.getEntity(mid);
    const e = world.getEntity(eid);
    if (!enemyIds.has(eid) || !e || !e.isValid) {
      if (m && m.isValid) {
        try { m.kill(); } catch (err) {}
      }
      marks.delete(eid);
    }
  }
  for (const e of enemies) {
    const mid = marks.get(e.id);
    const m = mid ? world.getEntity(mid) : undefined;
    if (m && m.isValid) {
      try {
        m.teleport({ x: e.location.x, y: e.location.y + 2.2, z: e.location.z });
      } catch (err) {}
    } else {
      try {
        const marker = indicatorEnt.dimension.spawnEntity("minecraft:armor_stand", { x: e.location.x, y: e.location.y + 2.2, z: e.location.z });
        marker.addEffect(INVISIBILITY, 1000000, { amplifier: 0, showParticles: false });
        marker.nameTag = "§d✦标记·" + e.name;
        marker.setDynamicProperty("jimie_marker_for", e.id);
        marks.set(e.id, marker.id);
      } catch (err) {}
    }
  }
  prophets.set(ind.id, marks);
}

function clearProphetMarks(indicatorId) {
  const marks = prophets.get(indicatorId) || new Map();
  for (const mid of marks.values()) {
    const m = world.getEntity(mid);
    if (m && m.isValid) {
      try { m.kill(); } catch (e) {}
    }
  }
  prophets.delete(indicatorId);
}

// ============ 佩莉阵眼 ============
function tickPeili() {
  for (const [oid, eid] of [...peiliIndicators]) {
    const ent = world.getEntity(eid);
    if (!ent || !ent.isValid) {
      peiliIndicators.delete(oid);
      continue;
    }
    const owner = world.getEntity(oid);
    let dead = true;
    if (owner && owner.isValid) {
      const hc = owner.getComponent("minecraft:health");
      dead = !hc || hc.currentValue <= 0;
    }
    beamParticles(
      ent.dimension,
      { x: ent.location.x, y: ent.location.y, z: ent.location.z },
      dead ? { red: 1.0, green: 0.15, blue: 0.15 } : { red: 0.95, green: 0.4, blue: 0.3 },
      dead ? 24 : 8
    );
  }
}

function handlePeiliRespawn(p) {
  const eid = peiliIndicators.get(p.id);
  if (!eid) return;
  const ent = world.getEntity(eid);
  if (ent && ent.isValid) {
    try {
      p.teleport({ x: ent.location.x, y: ent.location.y + 0.5, z: ent.location.z });
      p.sendMessage("§6你已通过阵眼复活");
    } catch (e) {}
    try { ent.kill(); } catch (e) {}
  }
  peiliIndicators.delete(p.id);
}

// ============ 芙希狼 ============
function tickWolves() {
  for (const [id, w] of [...wolves]) {
    const wolf = world.getEntity(id);
    if (!wolf || !wolf.isValid) {
      wolves.delete(id);
      continue;
    }
    try { wolf.addEffect(RESISTANCE, 40, { amplifier: 1, showParticles: false }); } catch (e) {}
    let remain = Number(wolf.getDynamicProperty("jimie_remain") || 0);
    if (remain <= 0) {
      try { wolf.kill(); } catch (e) {}
      wolves.delete(id);
      continue;
    }
    remain = Math.max(0, remain - 10);
    wolf.setDynamicProperty("jimie_remain", remain);
    w.expireTick = system.currentTick + remain;
  }
}

// ============ 布德宗图腾 ============
function tickTotems() {
  for (const p of world.getAllPlayers()) {
    const t1 = p.getDynamicProperty("jimie_tome1");
    const t2 = p.getDynamicProperty("jimie_tome2");
    if (t1 !== "buddha" && t2 !== "buddha") {
      totemState.delete(p.id);
      continue;
    }
    let st = totemState.get(p.id);
    const eq = p.getComponent("minecraft:equippable");
    const off = eq ? eq.getEquipment(EquipmentSlot.Offhand) : undefined;
    const hasTotem = !!off && off.typeId === "minecraft:totem_of_undying";
    if (!st) st = { had: hasTotem };
    let remain = Number(p.getDynamicProperty("jimie_totem_remain") || 0);
    if (st.had && !hasTotem) {
      try { p.removeEffect(REGEN); } catch (e) {}
      try { p.addEffect(REGEN, 260, { amplifier: 1 }); } catch (e) {}
      remain = 120;
      p.setDynamicProperty("jimie_totem_remain", remain);
      p.sendMessage("§6布德宗圣典：图腾触发，生命恢复II 13s，120s后补充图腾");
    }
    st.had = hasTotem;
    if (remain > 0) {
      remain = Math.max(0, remain - 0.5);
      p.setDynamicProperty("jimie_totem_remain", remain);
    }
    if (remain <= 0 && !hasTotem && eq) {
      try {
        eq.setEquipment(EquipmentSlot.Offhand, new ItemStack("minecraft:totem_of_undying"));
        st.had = true;
        p.sendMessage("§6布德宗圣典：不死图腾已补充");
      } catch (e) {}
    }
    totemState.set(p.id, st);
  }
}

// ============ 全局维护 ============
function tickMaintenance() {
  const now = system.currentTick;
  for (const p of world.getAllPlayers()) {
    const until = blessBoostUntil.get(p.id) || 0;
    if (now < until) {
      try { p.addEffect(HB, Math.min(40, until - now), { amplifier: 7, showParticles: false }); } catch (e) {}
    } else {
      if (blessBoostUntil.has(p.id)) blessBoostUntil.delete(p.id);
      try { p.addEffect(HB, 40, { amplifier: 4, showParticles: false }); } catch (e) {}
    }
    if (p.getDynamicProperty("jimie_school") === "life") {
      try { p.addEffect(REGEN, 40, { amplifier: 0, showParticles: false }); } catch (e) {}
    }
    const iu = immuneUntil.get(p.id) || 0;
    if (now < iu) removeNegatives(p);
    else if (immuneUntil.has(p.id)) immuneUntil.delete(p.id);
  }
  for (const [id, until] of [...fallImmuneUntil]) {
    if (now >= until) fallImmuneUntil.delete(id);
  }
}

// ============ 击杀判定（击灭丨勇战） ============
world.afterEvents.entityDie.subscribe((ev) => {
  const victim = ev.deadEntity;
  if (victim.typeId !== "minecraft:player") return;
  const src = ev.damageSource.damagingEntity;
  if (!src) return;
  let killer = null;
  if (src.typeId === "minecraft:player") killer = src;
  else if (src.typeId.indexOf("jimie:fuxi_wolf") === 0) {
    const oid = src.getDynamicProperty("jimie_owner");
    if (oid) killer = world.getAllPlayers().find((p) => p.id === oid);
  }
  if (!killer || killer.id === victim.id) return;
  if (!isEnemy(killer, victim)) return;
  if (killer.getDynamicProperty("jimie_school") === "jiemie") {
    try {
      killer.addEffect(STRENGTH, 100, { amplifier: 0 });
      killer.sendMessage("§c击灭丨勇战：力量I 5s");
    } catch (e) {}
  }
});

// ============ 掉落伤害免疫（突进施法者） ============
world.beforeEvents.entityHurt.subscribe((ev) => {
  const p = ev.hurtEntity;
  if (p.typeId !== "minecraft:player") return;
  if (String(ev.damageSource.cause) === "fall") {
    const until = fallImmuneUntil.get(p.id) || 0;
    if (system.currentTick < until) ev.cancel = true;
  }
});

// ============ 佩莉阵眼被攻击 ============
world.afterEvents.entityHurt.subscribe((ev) => {
  const ent = ev.hurtEntity;
  if (ent.typeId !== "jimie:peili_indicator") return;
  const attacker = ev.damageSource.damagingEntity;
  if (!attacker || attacker.typeId !== "minecraft:player") return;
  const ownerId = ent.getDynamicProperty("jimie_owner");
  const owner = ownerId ? world.getEntity(ownerId) : undefined;
  if (!owner || !isEnemy(attacker, owner)) return;
  let hits = Number(ent.getDynamicProperty("jimie_hits") || 0) + 1;
  ent.setDynamicProperty("jimie_hits", hits);
  ent.dimension.playSound("random.orb", ent.location);
  if (hits >= 3) {
    try { ent.kill(); } catch (e) {}
    peiliIndicators.delete(ownerId);
  }
});

// ============ 使用物品 ============
function handleUse(player, itemStack) {
  const id = itemStack.typeId;
  const now = system.currentTick;
  const prev = lastUse.get(player.id);
  if (prev && prev.tick === now && prev.id === id) return;
  lastUse.set(player.id, { tick: now, id: id });
  switch (id) {
    case "jimie:wand_bind": wandShot(player, 2); break;
    case "jimie:wand_life": wandShot(player, 1); break;
    case "jimie:charge": skillCharge(player); break;
    case "jimie:heal": skillHeal(player); break;
    case "jimie:slow_field": skillSlowField(player); break;
    case "jimie:poison_field": skillPoisonField(player); break;
    case "jimie:same_boat": skillSameBoat(player); break;
    case "jimie:bless": skillBless(player); break;
    case "jimie:dash": skillDash(player); break;
    case "jimie:stealth": skillStealth(player); break;
    case "jimie:tome_buddha": tomeBuddhaStatus(player); break;
    case "jimie:tome_priest": tomePriest(player); break;
    case "jimie:tome_knight": tomeKnight(player); break;
    case "jimie:tome_doctor": tomeDoctor(player); break;
    case "jimie:tome_summoner": tomeSummoner(player); break;
    case "jimie:tome_blade": tomeBlade(player); break;
    case "jimie:tome_herbalist": tomeHerbalist(player); break;
    case "jimie:tome_prophet": tomeProphet(player); break;
    case "jimie:tome_formation": tomeFormation(player); break;
    default: break;
  }
}

world.afterEvents.itemUse.subscribe((ev) => {
  if (ev.source && ev.source.typeId === "minecraft:player") handleUse(ev.source, ev.itemStack);
});

world.afterEvents.itemUseOn.subscribe((ev) => {
  if (ev.source && ev.source.typeId === "minecraft:player") handleUse(ev.source, ev.itemStack);
});

// ============ 聊天队伍切换（测试用） ============
world.beforeEvents.chatSend.subscribe((ev) => {
  const m = ev.message.trim().toLowerCase();
  if (m === "!team red" || m === "!team 红") {
    ev.cancel = true;
    setTeam(ev.sender, RED_TAG);
    return;
  }
  if (m === "!team blue" || m === "!team 蓝") {
    ev.cancel = true;
    setTeam(ev.sender, BLUE_TAG);
  }
});

// ============ 生成/复活 ============
world.afterEvents.playerSpawn.subscribe((ev) => {
  const p = ev.player;
  blessBoostUntil.delete(p.id);
  immuneUntil.delete(p.id);
  if (!p.hasTag(RED_TAG) && !p.hasTag(BLUE_TAG)) assignTeam(p);
  const school = p.getDynamicProperty("jimie_school");
  const tome1 = p.getDynamicProperty("jimie_tome1");
  if (!school) startSelection(p);
  else if (!tome1) chooseTome(p, []);
  else ensureLoadout(p);
  applyGlobalBoosts(p);
  if (!ev.initialSpawn) handlePeiliRespawn(p);
});

// ============ 启动扫描 ============
function loadIndicators() {
  for (const dimId of ["overworld", "nether", "the_end"]) {
    const dim = world.getDimension(dimId);
    let list = [];
    try { list = dim.getEntities({ type: "jimie:area_indicator" }); } catch (e) { continue; }
    for (const ent of list) {
      const remain = Math.max(0, Number(ent.getDynamicProperty("jimie_remain") || 0));
      const center = parseVec(String(ent.getDynamicProperty("jimie_center") || "0,0,0"));
      indicators.set(ent.id, {
        skill: String(ent.getDynamicProperty("jimie_skill") || ""),
        team: String(ent.getDynamicProperty("jimie_team") || ""),
        center: { x: center.x, y: center.y, z: center.z, dim: dimId },
        radius: Number(ent.getDynamicProperty("jimie_radius") || 0),
        effect: String(ent.getDynamicProperty("jimie_effect") || ""),
        amplifier: Number(ent.getDynamicProperty("jimie_amplifier") || 0),
        expireTick: system.currentTick + remain
      });
    }
  }
}

function loadWolves() {
  for (const typeId of ["jimie:fuxi_wolf_red", "jimie:fuxi_wolf_blue"]) {
    for (const dimId of ["overworld", "nether", "the_end"]) {
      const dim = world.getDimension(dimId);
      let list = [];
      try { list = dim.getEntities({ type: typeId }); } catch (e) { continue; }
      for (const wolf of list) {
        const remain = Math.max(0, Number(wolf.getDynamicProperty("jimie_remain") || 0));
        wolves.set(wolf.id, {
          ownerId: String(wolf.getDynamicProperty("jimie_owner") || ""),
          expireTick: system.currentTick + remain
        });
      }
    }
  }
}

function loadPeili() {
  for (const dimId of ["overworld", "nether", "the_end"]) {
    const dim = world.getDimension(dimId);
    let list = [];
    try { list = dim.getEntities({ type: "jimie:peili_indicator" }); } catch (e) { continue; }
    for (const ent of list) {
      const ownerId = String(ent.getDynamicProperty("jimie_owner") || "");
      if (ownerId) peiliIndicators.set(ownerId, ent.id);
    }
  }
}

function cleanupOldMarkers() {
  for (const dimId of ["overworld", "nether", "the_end"]) {
    const dim = world.getDimension(dimId);
    let list = [];
    try { list = dim.getEntities({ type: "minecraft:armor_stand" }); } catch (e) { continue; }
    for (const stand of list) {
      if (stand.getDynamicProperty("jimie_marker_for") !== undefined) {
        try { stand.kill(); } catch (e) {}
      }
    }
  }
}

function startup() {
  loadIndicators();
  loadWolves();
  loadPeili();
  cleanupOldMarkers();
  for (const p of world.getAllPlayers()) {
    if (!p.hasTag(RED_TAG) && !p.hasTag(BLUE_TAG)) assignTeam(p);
    applyGlobalBoosts(p);
    if (p.getDynamicProperty("jimie_school")) ensureLoadout(p);
  }
  system.runInterval(() => {
    tickMaintenance();
    tickIndicators();
    tickWolves();
    tickPeili();
    tickTotems();
  }, 10);
}

startup();
